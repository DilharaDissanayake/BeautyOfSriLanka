
 ******************************************************************************
 * Toolbar theme 
 *
 * Copyright (c) 2003-2006 Armin Burger
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. 
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

the images 'zoomin', 'zoomout', 'identify', 'select', 'wms' for theme2
are based on screenshots from the QGIS application
http://www.qgis.org
license at: http://www.gnu.org/copyleft/gpl.html


the images 'home', 'back', 'fwd', 'reload', 'print', 'download' for theme2
are based on screenshots from Mozilla Firefox default theme
http://www.mozilla.com/firefox
license at: http://www.mozilla.org/MPL/MPL-1.1.txt