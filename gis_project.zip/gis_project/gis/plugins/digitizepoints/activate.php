<?php
$_SESSION['digitizepoints_activated'] = true;
?>
