<?php

// locateXY plugin:
$_sl['locateXY_win'] = 'locateXY';
$_sl['locateXY_ZoomToXY'] = 'Zoomer vers';
$_sl['locateXY_NaN'] = 'Erreur de saisie des données';
$_sl['locateXY_Coordinates'] = 'Coordonnées géographiques';
$_sl['locateXY_Projection'] = 'Projection :';
$_sl['locateXY_Xtext1'] = 'X';
$_sl['locateXY_Xtext2'] = 'Longitude';
$_sl['locateXY_Ytext1'] = 'Y';
$_sl['locateXY_Ytext2'] = 'Latitude';
$_sl['locateXY_Text'] = 'Texte';
$_sl['locateXY_btnGo'] = 'Go';
$_sl['locateXY_ErrorProj'] = 'Erreur : plugin proj4js non activé !';

?>