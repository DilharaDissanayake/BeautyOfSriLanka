<?php

// selection management:
$_sl['selectionManagement_reloadMap'] = $_sl['Refresh Map'];
$_sl['selectionManagement_removeSelection'] = 'Remove current selection';
$_sl['selectionManagement_reloadSelection'] = 'Reload selection';
$_sl['selectionManagement_reloadError'] = 'Error during selection loading';
$_sl['selectionManagement_removeSelected__header'] = 'Remove';
$_sl['selectionManagement_removeSelected__object'] = 'Remove';

$_sl['selectionManagement_selOperator_text'] = 'Operation on selections';
$_sl['selectionManagement_selOperator_add_text'] = 'Add to current selection';
$_sl['selectionManagement_selOperator_del_text'] = 'Exclude from the current selection';
$_sl['selectionManagement_selOperator_intersec_text'] = 'Intersect with current selectione';
$_sl['selectionManagement_selOperator_new_text'] = 'Replace selection';


$_sl['selectionManagement_menuSelectionName'] = 'Selection';

$_sl['type_point'] = 'Point';
$_sl['type_line'] = 'Line';
$_sl['type_poly'] = 'Polygon';

?>