<?php

// sizeUpDownObj
$_sl['sizeUpDownObj__size_up'] = 'Increase objets size';
$_sl['sizeUpDownObj__size_down'] = 'Decrease objets size';
$_sl['sizeUpDownObj__size_reset'] = 'Reset objets size';
$_sl['sizeUpDownObj__size_resetall'] = 'Reset all layers size';
$_sl['sizeUpDownObj__ret_1'] = 'Max increase iteration reached.';
$_sl['sizeUpDownObj__ret_2'] = 'Max decrease iteration reached.';
$_sl['sizeUpDownObj__Caption'] = 'Update objets size.';

?>