<?php

// unitAndProj
$_sl['unitAndProj__units'] = 'Unit';
$_sl['unitAndProj__0'] = 'inches';
$_sl['unitAndProj__1'] = 'feet';
$_sl['unitAndProj__2'] = 'miles';
$_sl['unitAndProj__3'] = 'meters';
$_sl['unitAndProj__4'] = 'kilometers';
$_sl['unitAndProj__5'] = 'dd';
$_sl['unitAndProj__6'] = 'pixels';
$_sl['unitAndProj__7'] = 'nauticalmiles';
$_sl['unitAndProj__proj'] = 'Projection';
$_sl['unitAndProj__projNotDef'] = 'description not available';

?>